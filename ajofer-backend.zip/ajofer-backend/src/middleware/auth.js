const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('ERRO: variável de ambiente JWT_SECRET não definida. Veja o README.md.');
  process.exit(1);
}

const TOKEN_EXPIRY = '12h';

function signToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, role: user.role },
    JWT_SECRET,
    { expiresIn: TOKEN_EXPIRY }
  );
}

function authenticateToken(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'Token de autenticação ausente.' });
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = { id: payload.sub, username: payload.username, role: payload.role };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido ou expirado.' });
  }
}

// Regras de senha: mínimo 8 caracteres, 1 maiúscula, 1 número, 1 caractere especial
const SPECIAL_RE = /[_/@.#$%&*!?-]/;
function isPasswordValid(pw) {
  if (typeof pw !== 'string') return false;
  return (
    pw.length >= 8 &&
    /[A-Z]/.test(pw) &&
    /[0-9]/.test(pw) &&
    SPECIAL_RE.test(pw)
  );
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

module.exports = { signToken, authenticateToken, isPasswordValid, EMAIL_RE };
