const express = require('express');
const bcrypt = require('bcryptjs');
const { pool } = require('../db');
const { signToken, authenticateToken, isPasswordValid, EMAIL_RE } = require('../middleware/auth');

const router = express.Router();
const SALT_ROUNDS = 10;

// POST /api/auth/register  { nome, email, username, password }
// Usado pela tela "Cadastro de funcionário"
router.post('/register', async (req, res) => {
  try {
    const { nome, email, username, password } = req.body || {};

    if (!nome || typeof nome !== 'string' || !nome.trim()) {
      return res.status(400).json({ error: 'Informe o nome completo.' });
    }
    if (!email || !EMAIL_RE.test(email)) {
      return res.status(400).json({ error: 'Informe um e-mail válido.' });
    }
    if (!username || typeof username !== 'string' || username.trim().length < 3) {
      return res.status(400).json({ error: 'O nome de usuário deve ter ao menos 3 caracteres.' });
    }
    if (!isPasswordValid(password)) {
      return res.status(400).json({
        error: 'A senha deve ter ao menos 8 caracteres, uma letra maiúscula, um número e um caractere especial (_ / @ . # $ % & *).',
      });
    }

    const usernameNorm = username.trim();
    const emailNorm = email.trim().toLowerCase();

    const existing = await pool.query(
      `SELECT id FROM users WHERE lower(username) = lower($1) OR lower(email) = $2`,
      [usernameNorm, emailNorm]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Já existe um usuário com este login ou e-mail.' });
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

    const { rows } = await pool.query(
      `INSERT INTO users (nome, email, username, password_hash)
       VALUES ($1, $2, $3, $4)
       RETURNING id, nome, email, username, role, created_at`,
      [nome.trim(), emailNorm, usernameNorm, passwordHash]
    );

    return res.status(201).json({ user: rows[0] });
  } catch (err) {
    console.error('Erro em /register:', err);
    return res.status(500).json({ error: 'Erro interno ao cadastrar funcionário.' });
  }
});

// POST /api/auth/login  { username, password }
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: 'Informe login e senha.' });
    }

    const { rows } = await pool.query(
      `SELECT id, nome, email, username, password_hash, role FROM users WHERE lower(username) = lower($1)`,
      [username.trim()]
    );
    const user = rows[0];
    if (!user) {
      return res.status(401).json({ error: 'Login ou senha inválidos.' });
    }

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: 'Login ou senha inválidos.' });
    }

    const token = signToken(user);
    return res.json({
      token,
      user: { id: user.id, nome: user.nome, email: user.email, username: user.username, role: user.role },
    });
  } catch (err) {
    console.error('Erro em /login:', err);
    return res.status(500).json({ error: 'Erro interno ao entrar.' });
  }
});

// POST /api/auth/forgot-password  { username, email, newPassword }
// Redefine a senha após confirmar login + e-mail cadastrados (sem envio de e-mail real).
router.post('/forgot-password', async (req, res) => {
  try {
    const { username, email, newPassword } = req.body || {};
    if (!username || !email) {
      return res.status(400).json({ error: 'Informe login e e-mail cadastrados.' });
    }
    if (!isPasswordValid(newPassword)) {
      return res.status(400).json({
        error: 'A nova senha deve ter ao menos 8 caracteres, uma letra maiúscula, um número e um caractere especial.',
      });
    }

    const { rows } = await pool.query(
      `SELECT id FROM users WHERE lower(username) = lower($1) AND lower(email) = lower($2)`,
      [username.trim(), email.trim()]
    );
    const user = rows[0];
    if (!user) {
      return res.status(404).json({ error: 'Não encontramos um usuário com esse login e e-mail.' });
    }

    const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);
    await pool.query(`UPDATE users SET password_hash = $1 WHERE id = $2`, [passwordHash, user.id]);

    return res.json({ ok: true });
  } catch (err) {
    console.error('Erro em /forgot-password:', err);
    return res.status(500).json({ error: 'Erro interno ao redefinir senha.' });
  }
});

// GET /api/auth/me  (requer token) - útil para validar sessão ao recarregar a página
router.get('/me', authenticateToken, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT id, nome, email, username, role FROM users WHERE id = $1`,
    [req.user.id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Usuário não encontrado.' });
  return res.json({ user: rows[0] });
});

module.exports = router;
