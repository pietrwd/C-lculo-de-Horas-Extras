const express = require('express');
const { pool } = require('../db');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();
const WORKSPACE_ID = 'default';

// GET /api/dashboard  (requer token) -> { state, logo, updatedAt, updatedBy }
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT state, logo, updated_at, updated_by FROM dashboard_data WHERE workspace_id = $1`,
      [WORKSPACE_ID]
    );
    if (!rows[0]) {
      return res.json({ state: null, logo: null, updatedAt: null });
    }
    return res.json({
      state: rows[0].state,
      logo: rows[0].logo,
      updatedAt: rows[0].updated_at,
    });
  } catch (err) {
    console.error('Erro em GET /dashboard:', err);
    return res.status(500).json({ error: 'Erro interno ao carregar o dashboard.' });
  }
});

// PUT /api/dashboard  (requer token)  { state, logo }
// Usado pelo botão "Salvar alterações" e pela troca de logotipo.
router.put('/', authenticateToken, async (req, res) => {
  try {
    const { state, logo } = req.body || {};
    if (!state || typeof state !== 'object') {
      return res.status(400).json({ error: 'Estado do dashboard inválido.' });
    }

    await pool.query(
      `INSERT INTO dashboard_data (workspace_id, state, logo, updated_by, updated_at)
       VALUES ($1, $2::jsonb, $3, $4, now())
       ON CONFLICT (workspace_id)
       DO UPDATE SET state = EXCLUDED.state, logo = EXCLUDED.logo,
                     updated_by = EXCLUDED.updated_by, updated_at = now()`,
      [WORKSPACE_ID, JSON.stringify(state), logo || null, req.user.id]
    );

    return res.json({ ok: true, updatedAt: new Date().toISOString() });
  } catch (err) {
    console.error('Erro em PUT /dashboard:', err);
    return res.status(500).json({ error: 'Erro interno ao salvar o dashboard.' });
  }
});

module.exports = router;
